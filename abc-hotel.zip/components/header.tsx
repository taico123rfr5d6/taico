"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="font-serif text-2xl font-bold tracking-tight" style={{ fontFamily: "var(--font-playfair)" }}>
            ABC HOTEL
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#about" className="text-sm font-medium hover:text-accent transition-colors">
              About
            </a>
            <a href="#amenities" className="text-sm font-medium hover:text-accent transition-colors">
              Amenities
            </a>
            <a href="#rooms" className="text-sm font-medium hover:text-accent transition-colors">
              Rooms
            </a>
            <a href="#gallery" className="text-sm font-medium hover:text-accent transition-colors">
              Gallery
            </a>
            <a href="#contact" className="text-sm font-medium hover:text-accent transition-colors">
              Contact
            </a>
          </nav>

          <div className="hidden md:block">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Book Now</Button>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)} aria-label="Toggle menu">
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden py-4 border-t border-border">
            <div className="flex flex-col gap-4">
              <a href="#about" className="text-sm font-medium hover:text-accent transition-colors">
                About
              </a>
              <a href="#amenities" className="text-sm font-medium hover:text-accent transition-colors">
                Amenities
              </a>
              <a href="#rooms" className="text-sm font-medium hover:text-accent transition-colors">
                Rooms
              </a>
              <a href="#gallery" className="text-sm font-medium hover:text-accent transition-colors">
                Gallery
              </a>
              <a href="#contact" className="text-sm font-medium hover:text-accent transition-colors">
                Contact
              </a>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 w-full">Book Now</Button>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}
