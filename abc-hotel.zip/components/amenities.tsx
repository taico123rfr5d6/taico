import { Wifi, Utensils, Dumbbell, Waves, Car, Sparkles } from "lucide-react"

const amenities = [
  {
    icon: Wifi,
    title: "High-Speed WiFi",
    description: "Complimentary high-speed internet throughout the property",
  },
  {
    icon: Utensils,
    title: "Fine Dining",
    description: "Michelin-starred restaurant and 24-hour room service",
  },
  {
    icon: Dumbbell,
    title: "Fitness Center",
    description: "State-of-the-art gym with personal trainers available",
  },
  {
    icon: Waves,
    title: "Infinity Pool",
    description: "Rooftop pool with panoramic city views",
  },
  {
    icon: Car,
    title: "Valet Parking",
    description: "Complimentary valet and secure parking facilities",
  },
  {
    icon: Sparkles,
    title: "Spa & Wellness",
    description: "Full-service spa offering rejuvenating treatments",
  },
]

export function Amenities() {
  return (
    <section id="amenities" className="py-24 md:py-32 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2
            className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold mb-4 text-balance"
            style={{ fontFamily: "var(--font-playfair)" }}
          >
            World-Class Amenities
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Indulge in our exceptional facilities designed to enhance your stay
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {amenities.map((amenity, index) => (
            <div
              key={index}
              className="bg-card p-8 rounded-sm border border-border hover:border-accent transition-colors"
            >
              <amenity.icon className="w-12 h-12 text-accent mb-4" />
              <h3 className="text-xl font-semibold mb-2">{amenity.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{amenity.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
