export function About() {
  return (
    <section id="about" className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div>
            <h2
              className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance"
              style={{ fontFamily: "var(--font-playfair)" }}
            >
              Where Elegance Meets Excellence
            </h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                ABC Hotel stands as a beacon of luxury hospitality, offering an unparalleled 5-star experience in the
                heart of the city. Our commitment to excellence is reflected in every detail, from our meticulously
                designed suites to our world-class amenities.
              </p>
              <p>
                With over two decades of distinguished service, we have perfected the art of hospitality. Our dedicated
                team ensures that every guest receives personalized attention, creating memorable experiences that
                exceed expectations.
              </p>
              <p>
                Whether you're traveling for business or leisure, ABC Hotel provides the perfect sanctuary where
                sophistication and comfort converge seamlessly.
              </p>
            </div>
          </div>
          <div className="relative h-[500px] md:h-[600px]">
            <img
              src="/luxury-hotel-exterior-architecture-5-star.jpg"
              alt="ABC Hotel Exterior"
              className="w-full h-full object-cover rounded-sm"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
