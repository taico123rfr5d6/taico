export function Gallery() {
  const images = [
    "/luxury-hotel-restaurant-fine-dining.jpg",
    "/luxury-hotel-spa-wellness-center.jpg",
    "/luxury-hotel-rooftop-pool-sunset.jpg",
    "/luxury-hotel-bar-lounge-elegant.jpg",
  ]

  return (
    <section id="gallery" className="py-24 md:py-32 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2
            className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold mb-4 text-balance"
            style={{ fontFamily: "var(--font-playfair)" }}
          >
            Gallery
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            A glimpse into the ABC Hotel experience
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          {images.map((image, index) => (
            <div key={index} className="relative h-80 overflow-hidden rounded-sm group cursor-pointer">
              <img
                src={image || "/placeholder.svg"}
                alt={`Gallery image ${index + 1}`}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
