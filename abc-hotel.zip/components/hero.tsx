import { Button } from "@/components/ui/button"
import { ChevronDown } from "lucide-react"

export function Hero() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img src="/luxury-5-star-hotel-lobby-elegant-interior.jpg" alt="ABC Hotel Luxury Interior" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/40" />
      </div>

      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        <h1
          className="font-serif text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 tracking-tight text-balance"
          style={{ fontFamily: "var(--font-playfair)" }}
        >
          Experience Timeless Luxury
        </h1>
        <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto text-pretty">
          Discover unparalleled elegance and exceptional service at ABC Hotel, where every moment becomes an
          unforgettable memory
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 text-base px-8">
            Reserve Your Stay
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-white/10 text-white border-white/30 hover:bg-white/20 backdrop-blur-sm text-base px-8"
          >
            Explore Rooms
          </Button>
        </div>
      </div>

      <a
        href="#about"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 text-white animate-bounce"
        aria-label="Scroll down"
      >
        <ChevronDown size={32} />
      </a>
    </section>
  )
}
