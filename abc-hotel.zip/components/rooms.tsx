import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

const rooms = [
  {
    name: "Deluxe Suite",
    size: "45 m²",
    guests: "2 Guests",
    price: "$350",
    image: "/luxury-hotel-deluxe-suite-bedroom.jpg",
  },
  {
    name: "Executive Suite",
    size: "65 m²",
    guests: "3 Guests",
    price: "$550",
    image: "/luxury-hotel-executive-suite-living-room.jpg",
  },
  {
    name: "Presidential Suite",
    size: "120 m²",
    guests: "4 Guests",
    price: "$1,200",
    image: "/luxury-hotel-presidential-suite-panoramic.jpg",
  },
]

export function Rooms() {
  return (
    <section id="rooms" className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2
            className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold mb-4 text-balance"
            style={{ fontFamily: "var(--font-playfair)" }}
          >
            Luxurious Accommodations
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Choose from our selection of elegantly appointed suites
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {rooms.map((room, index) => (
            <Card key={index} className="overflow-hidden border-border hover:border-accent transition-colors group">
              <div className="relative h-64 overflow-hidden">
                <img
                  src={room.image || "/placeholder.svg"}
                  alt={room.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <CardContent className="p-6">
                <h3 className="text-2xl font-semibold mb-3">{room.name}</h3>
                <div className="flex gap-4 text-sm text-muted-foreground mb-4">
                  <span>{room.size}</span>
                  <span>•</span>
                  <span>{room.guests}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-3xl font-bold text-accent">{room.price}</span>
                    <span className="text-muted-foreground"> / night</span>
                  </div>
                  <Button
                    variant="outline"
                    className="border-accent text-accent hover:bg-accent hover:text-accent-foreground bg-transparent"
                  >
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
