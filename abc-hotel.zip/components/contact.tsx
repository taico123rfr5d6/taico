import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { MapPin, Phone, Mail } from "lucide-react"

export function Contact() {
  return (
    <section id="contact" className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 lg:gap-16">
          <div>
            <h2
              className="font-serif text-4xl md:text-5xl font-bold mb-6 text-balance"
              style={{ fontFamily: "var(--font-playfair)" }}
            >
              Get in Touch
            </h2>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              Our concierge team is available 24/7 to assist you with reservations, inquiries, or special requests.
            </p>

            <div className="space-y-6">
              <div className="flex gap-4">
                <MapPin className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold mb-1">Address</h3>
                  <p className="text-muted-foreground">123 Luxury Avenue, City Center, 10001</p>
                </div>
              </div>
              <div className="flex gap-4">
                <Phone className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold mb-1">Phone</h3>
                  <p className="text-muted-foreground">+1 (555) 123-4567</p>
                </div>
              </div>
              <div className="flex gap-4">
                <Mail className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold mb-1">Email</h3>
                  <p className="text-muted-foreground">reservations@abchotel.com</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-card p-8 rounded-sm border border-border">
            <form className="space-y-6">
              <div>
                <Input placeholder="Your Name" className="bg-background" />
              </div>
              <div>
                <Input type="email" placeholder="Email Address" className="bg-background" />
              </div>
              <div>
                <Input type="tel" placeholder="Phone Number" className="bg-background" />
              </div>
              <div>
                <Textarea placeholder="Your Message" rows={5} className="bg-background resize-none" />
              </div>
              <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90">Send Message</Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
